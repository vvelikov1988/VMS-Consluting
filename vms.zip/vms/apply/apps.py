from django.apps import AppConfig


class ApplyConfig(AppConfig):
    name = 'apply'
